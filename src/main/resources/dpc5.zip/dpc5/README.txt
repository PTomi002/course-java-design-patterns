1. You will need at least JDK 10 to build and run these exercises.

2. Recommended IDE is IntelliJ IDEA, but Eclipse Oxygen.3a or later should also work.

  2.1. For IntelliJ IDEA users, all you should need to do is open the
  dpc5.ipr file.

  2.2. For Eclipse users, please do the following:
    2.2.1. Open Eclipse
    2.2.2. Go to "File->Import..."
    2.2.3. Select "General->Existing Project into Workspace" and click "Next"
    2.2.4. "Select root directory" should point to this directory
    2.2.5. Click "Finish"

  For both IDEs, you might also have to set up your JDK 10.
